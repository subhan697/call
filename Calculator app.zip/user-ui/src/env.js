export const env = { ...process.env, ...window['env'] }
